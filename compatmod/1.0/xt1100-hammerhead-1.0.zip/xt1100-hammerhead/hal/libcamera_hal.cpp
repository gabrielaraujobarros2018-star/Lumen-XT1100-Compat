/*
 * libcamera_hal.cpp - Nexus 6 Camera HAL 3.0 Wrapper
 * Motorola XT1100 Hammerhead (Shamu) - libcamera.c 1.0 + dcam.c Integration
 * Android Camera2 API → Custom /dev/camera0 driver bridge
 * ARMv7-A Snapdragon 805 optimized
 *
 * Path: /system/hw/motorola-nexus-hammerhead/xt1100-hammerhead/hal/
 * Loaded as: libcamera.mot_shamu.so
 */

#define LOG_TAG "LibCameraHAL"
#define LOG_NDEBUG 0

#include <log/log.h>
#include <hardware/camera3.h>
#include <hardware/camera_common.h>
#include <cutils/properties.h>
#include <system/camera_metadata.h>
#include <dlfcn.h>
#include <pthread.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>

#include <linux/ioctl.h>
#include "libcamera.h"  // libcamera.c 1.0 exported headers

// Nexus 6 specific constants
#define NEXUS6_SENSOR_WIDTH    4128  // IMX214
#define NEXUS6_SENSOR_HEIGHT   3096
#define CAMERA_DEVICE_API_VERSION_3_4  HARDWARE_MAKE_API_VERSION(3,4)

// Global HAL state
static camera_handle_t *g_cam_handle = NULL;
static warnings_handle_t *g_warnings = NULL;
static error_handler_t *g_error_handler = NULL;
static perf_monitor_t *g_perf_monitor = NULL;
static mem_manager_t *g_mem_manager = NULL;
static pthread_mutex_t g_hal_lock = PTHREAD_MUTEX_INITIALIZER;

// Static metadata for Camera2 API
static const camera_metadata_t *g_static_metadata = NULL;

// Forward declarations
static int hal_init();
static void hal_configure_metadata();
static int camera_device_construct(const hw_module_t *module, const char *name,
                                  const hw_config_t *config, struct hw_device_t **device);

/*
 * Camera HAL Module v3.4 (Nexus 6 compatible)
 */
static struct hw_module_methods_t hal_module_methods = {
    .open = camera_device_construct,
};

static struct camera_module_methods_t camera_module_methods = {
    .open_legacy = NULL,
    .get_number_of_cameras = NULL,
    .get_camera_info = NULL,
    .open = NULL,
};

struct camera_module HALModule = {
    .common = {
        .tag = HARDWARE_MODULE_TAG,
        .module_api_version = CAMERA_MODULE_API_VERSION_2_4,
        .hal_api_version = HARDWARE_MAKE_API_VERSION(3,4),
        .id = CAMERA_HARDWARE_MODULE_ID,
        .name = "Motorola Nexus 6 LibCamera HAL 1.0",
        .author = "LumenOS Camera Team",
        .methods = &hal_module_methods,
        .dso = NULL,
        .reserved = {0},
    },
    .get_number_of_cameras = NULL,
    .get_camera_info = NULL,
    .set_callbacks = NULL,
    .get_metadata_vendor_tag_ops = NULL,
    .set_torch_mode = NULL,
    .open_legacy = NULL,
    .set_video_buffer_mode = NULL,
    .register_face_detect_callback = NULL,
    .open = NULL,
};

// Camera3 device implementation
struct camera3_device_t {
    hw_device_t common;
    int id;
    camera_handle_t *cam_handle;
    struct dcam_config config;
    int streaming;
    int preview_active;
    pthread_t preview_thread;
    uint32_t frame_count;
};

/*
 * HAL Initialization - Connects Android Camera2 → libcamera.c → dcam.c
 */
static int hal_init() {
    ALOGI("LibCameraHAL: Initializing Nexus 6 XT1100 HAL");
    
    // Initialize libcamera.c 1.0 stack
    pthread_mutex_lock(&g_hal_lock);
    
    if (g_cam_handle) {
        ALOGW("HAL already initialized");
        pthread_mutex_unlock(&g_hal_lock);
        return 0;
    }
    
    // Full libcamera.c stack initialization
    g_cam_handle = camera_init();
    if (!g_cam_handle) {
        ALOGE("Failed to initialize libcamera.c");
        pthread_mutex_unlock(&g_hal_lock);
        return -ENODEV;
    }
    
    g_warnings = warnings_init(1000);
    g_error_handler = error_handler_init(g_warnings);
    g_perf_monitor = perf_monitor_init(g_cam_handle, g_warnings, g_error_handler, 30.0f);
    
    // Nexus 6 memory pool config: DMA, Stream, Preview
    uint32_t pools[][3] = {
        {MEM_POOL_DMA,    8,  1920*1080*3/2},  // 1080p YUV
        {MEM_POOL_STREAM, 4,  640*480*3/2},    // Preview
        {MEM_POOL_CACHED, 16, 64*1024}         // Metadata
    };
    g_mem_manager = mem_manager_init(pools, 3);
    
    // Configure default 1080p30
    g_cam_handle->config.width = 1920;
    g_cam_handle->config.height = 1080;
    g_cam_handle->config.fps = 30;
    camera_set_config(g_cam_handle, &g_cam_handle->config);
    
    hal_configure_metadata();
    
    ALOGI("LibCameraHAL: Nexus 6 camera stack ready (IMX214 13MP)");
    pthread_mutex_unlock(&g_hal_lock);
    return 0;
}

/*
 * Static metadata for Android Camera2 API (Nexus 6 IMX214)
 */
static void hal_configure_metadata() {
    camera_metadata_writer_t writer;
    
    // Allocate metadata buffer (Nexus 6 capabilities)
    size_t entry_count = 52;
    uint32_t data_size = 0;
    uint8_t *data = allocate_camera_metadata_writer(entry_count, &data_size, &writer);
    
    if (!data) {
        ALOGE("Failed to allocate static metadata");
        return;
    }
    
    // Basic camera characteristics
    writer.uint8(ANDROID_CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES, 1, (uint8_t[]){30,30});
    writer.uint32(ANDROID_SENSOR_INFO_PIXEL_ARRAY_SIZE, 0, NEXUS6_SENSOR_WIDTH, NEXUS6_SENSOR_HEIGHT);
    writer.uint32(ANDROID_SENSOR_MAX_ANALOG_SENSITIVITY, 0, 6400);  // ISO 6400
    writer.uint32(ANDROID_SENSOR_ORIENTATION, 0, 90);  // Portrait
    
    // Supported formats and sizes
    uint32_t formats[] = {HAL_PIXEL_FORMAT_YUV_420_888, HAL_PIXEL_FORMAT_IMPLEMENTATION_DEFINED};
    writer.uint32(ANDROID_STREAM_CONFIGURATION_MAP_OUTPUT_FORMATS, 2, formats);
    
    uint32_t widths[] = {1920, 1280, 640, 320};
    uint32_t heights[] = {1080, 720, 480, 240};
    writer.uint32(ANDROID_STREAM_CONFIGURATION_MAP_OUTPUT_SIZES, 8, widths, heights);
    
    // Capabilities
    uint32_t capabilities[] = {CAMERA_DEVICE_CAPABILITY_CONCURRENT_STREAM};
    writer.uint32(ANDROID_REQUEST_AVAILABLE_CAPABILITIES, 1, capabilities);
    
    // Finalize metadata
    g_static_metadata = writer.metadata;
    
    ALOGI("Static metadata configured: %zu entries", entry_count);
}

/*
 * Create camera device instance
 */
static int camera_device_construct(const hw_module_t *module, const char *name,
                                  const hw_config_t *config, struct hw_device_t **device) {
    
    if (hal_init() != 0) {
        return -ENODEV;
    }
    
    struct camera3_device_t *cam_dev = (struct camera3_device_t*)calloc(1, sizeof(*cam_dev));
    if (!cam_dev) {
        return -ENOMEM;
    }
    
    // Initialize device
    cam_dev->common.tag = HARDWARE_DEVICE_TAG;
    cam_dev->common.version = CAMERA_DEVICE_API_VERSION_3_4;
    cam_dev->common.close = hal_close;
    cam_dev->id = 0;  // Rear camera
    
    cam_dev->cam_handle = g_cam_handle;
    
    *device = &cam_dev->common;
    ALOGI("Camera3 device created ID=%d", cam_dev->id);
    
    return 0;
}

static int hal_close(struct hw_device_t *dev) {
    struct camera3_device_t *cam_dev = (struct camera3_device_t*)dev;
    
    if (cam_dev->preview_active) {
        preview_stop(cam_dev->cam_handle->preview);
    }
    
    free(cam_dev);
    ALOGI("Camera3 device closed");
    return 0;
}

/*
 * Camera3 Callback Interface → libcamera.c Pipeline
 */
static int camera_device_configure_streams(camera3_device_t *dev,
                                          camera3_stream_configuration_t *stream_list,
                                          camera3_stream_configuration_mode_t mode) {
    
    struct camera3_device_t *cam_dev = (struct camera3_device_t*)dev;
    pthread_mutex_lock(&g_hal_lock);
    
    // Configure main preview stream (1080p30)
    for (uint32_t i = 0; i < stream_list->num_streams; i++) {
        camera3_stream_t *stream = stream_list->streams[i];
        
        if (stream->width == 1920 && stream->height == 1080) {
            cam_dev->config.width = 1920;
            cam_dev->config.height = 1080;
            cam_dev->config.fps = 30;
            camera_set_config(cam_dev->cam_handle, &cam_dev->config);
            ALOGI("Main stream configured: 1920x1080@30fps");
        }
    }
    
    pthread_mutex_unlock(&g_hal_lock);
    return 0;
}

static const camera_metadata_t* camera_device_get_static_metadata(
        const struct camera3_device *dev, uint32_t *out_size) {
    
    *out_size = get_camera_metadata_entry_count(g_static_metadata) * sizeof(camera_metadata_ro_entry);
    return g_static_metadata;
}

static int camera_device_start_streaming(struct camera3_device *dev,
                                        camera3_stream_t **streams, uint32_t num_streams) {
    
    struct camera3_device_t *cam_dev = (struct camera3_device_t*)dev;
    
    // Start libcamera.c streaming pipeline
    stream_handle_t *stream = stream_init(cam_dev->cam_handle, 4);
    perf_record_frame(g_perf_monitor, "hal_start_streaming");
    
    // PiP preview pipeline
    preview_handle_t *preview = preview_init(cam_dev->cam_handle, 640, 480);
    
    cam_dev->streaming = 1;
    cam_dev->preview_active = 1;
    
    ALOGI("Camera3 streaming started: libcamera → dcam pipeline active");
    return 0;
}

static int camera_device_stop_streaming(struct camera3_device *dev,
                                       camera3_stream_t **streams, uint32_t num_streams) {
    
    struct camera3_device_t *cam_dev = (struct camera3_device_t*)dev;
    
    cam_dev->streaming = 0;
    cam_dev->preview_active = 0;
    
    ALOGI("Camera3 streaming stopped");
    return 0;
}

// Export HAL module
__attribute__ ((visibility ("default")))
camera_module_t HAL_MODULE_INFO_SYM = {
    .common = {
        .tag = HARDWARE_MODULE_TAG,
        .module_api_version = CAMERA_MODULE_API_VERSION_2_4,
        .hal_api_version = HARDWARE_MAKE_API_VERSION(3,4),
        .id = CAMERA_HARDWARE_MODULE_ID,
        .name = "LibCamera HAL 1.0",
        .author = "LumenOS",
        .methods = &hal_module_methods,
    },
};

static const struct camera3_device_ops_t camera3_device_ops = {
    .initialize = NULL,
    .configure_streams = camera_device_configure_streams,
    .register_stream_buffers = NULL,
    .register_reprocess_buffers = NULL,
    .validate_capture_request = NULL,
    .construct_default_request_settings = NULL,
    .process_capture_request = NULL,
    .get_metadata_vendor_tag_ops = NULL,
    .dump = NULL,
    .flush = NULL,
    .reserved = {},
};