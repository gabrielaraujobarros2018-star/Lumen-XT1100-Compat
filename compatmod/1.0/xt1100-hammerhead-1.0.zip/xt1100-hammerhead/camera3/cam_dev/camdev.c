/*
 * camdev.c - Nexus 6 Camera Device Manager
 * Motorola XT1100 Hammerhead (Shamu) - Unified Camera Device Interface
 * Orchestrates libcamera.c + dcam.c + HAL3 + PiP + Threading
 * ARMv7-A Snapdragon 805 Production Device Manager
 *
 * SINGLE ENTRY POINT for all camera operations
 * Path: /system/hw/.../camera3/camdev.c
 */

#define LOG_TAG "CamDev"
#define ALOG_NDEBUG 0

#include <hardware/camera3.h>
#include <pthread.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>

// Internal headers
#include "libcamera.h"           // libcamera.c 1.0
#include "pthread_mutex_lock.c"  // Threading system
#include "cam3_pip.c"            // PiP pipeline
#include "camera_pip_config.h"   // XML config

// Nexus 6 device capabilities
#define CAMDEV_MAX_CAMERAS     2   // Rear + Front
#define CAMDEV_SENSOR_ID_REAR  0
#define CAMDEV_SENSOR_ID_FRONT 1
#define CAMDEV_DEFAULT_FPS     30

// Unified camera device state
typedef struct {
    int id;                           // 0=REAR, 1=FRONT
    char name[32];                    // "rear", "front"
    
    // libcamera.c handles
    camera_handle_t *cam_handle;
    stream_handle_t *stream_handle;
    preview_handle_t *preview_handle;
    
    // Threading
    hal_mutex_t device_mutex;
    volatile int streaming;
    volatile int preview_active;
    
    // Device state
    struct dcam_config config;
    uint64_t frame_counter;
    float current_fps;
    
    // HAL3 integration
    camera3_device_t hal3_device;
    
    // PiP state
    int pip_enabled;
    
    // File descriptors
    int dcam_fd;                      // /dev/camera0
} camdev_t;

// Global device array
static camdev_t g_devices[CAMDEV_MAX_CAMERAS];
static int g_devices_initialized = 0;

// Forward declarations
static int camdev_init_device(camdev_t *dev, int id);
static int camdev_open_dcam(camdev_t *dev);

/*
 * Initialize ALL Nexus 6 camera devices
 * Called once at HAL boot
 */
int camdev_init_all(void) {
    ALOGI("CamDev: Initializing Nexus 6 camera devices (XT1100 Shamu)");
    
    if (g_devices_initialized) {
        ALOGW("Devices already initialized");
        return 0;
    }
    
    // Initialize HAL threading system
    hal_threading_init();
    
    // Initialize rear camera (IMX214 primary)
    strcpy(g_devices[CAMDEV_SENSOR_ID_REAR].name, "rear");
    camdev_init_device(&g_devices[CAMDEV_SENSOR_ID_REAR], CAMDEV_SENSOR_ID_REAR);
    
    // Initialize front camera (OV2720 secondary)  
    strcpy(g_devices[CAMDEV_SENSOR_ID_FRONT].name, "front");
    camdev_init_device(&g_devices[CAMDEV_SENSOR_ID_FRONT], CAMDEV_SENSOR_ID_FRONT);
    
    g_devices_initialized = 1;
    ALOGI("CamDev: %d devices initialized - libcamera.c + dcam.c ready", CAMDEV_MAX_CAMERAS);
    return 0;
}

/*
 * Initialize single camera device
 */
static int camdev_init_device(camdev_t *dev, int id) {
    int ret;
    
    dev->id = id;
    dev->frame_counter = 0;
    dev->current_fps = 0.0f;
    dev->pip_enabled = 0;
    
    // Device mutex (deadlock-free)
    hal_mutex_init(&dev->device_mutex, HAL_LOCK_CONFIG, dev->name);
    
    // Open dcam.c kernel driver
    ret = camdev_open_dcam(dev);
    if (ret < 0) {
        ALOGE("CamDev: Failed to open /dev/camera%d", id);
        return ret;
    }
    
    // Initialize libcamera.c stack
    dev->cam_handle = camera_init();
    if (!dev->cam_handle) {
        ALOGE("CamDev: libcamera.c init failed for %s", dev->name);
        return -ENODEV;
    }
    
    // Default config: 1080p30
    dev->config.width = 1920;
    dev->config.height = 1080;
    dev->config.fps = CAMDEV_DEFAULT_FPS;
    dev->config.format = 1;  // YUV
    
    camera_set_config(dev->cam_handle, &dev->config);
    
    // Initialize streaming handles
    dev->stream_handle = stream_init(dev->cam_handle, 4);
    dev->preview_handle = preview_init(dev->cam_handle, 640, 480);
    
    ALOGI("CamDev: %s camera ready (ID=%d, fd=%d)", dev->name, id, dev->dcam_fd);
    return 0;
}

/*
 * Open dcam.c kernel driver (/dev/camera0)
 */
static int camdev_open_dcam(camdev_t *dev) {
    char device_path[32];
    snprintf(device_path, sizeof(device_path), "/dev/camera%d", dev->id);
    
    dev->dcam_fd = open(device_path, O_RDWR | O_NONBLOCK);
    if (dev->dcam_fd < 0) {
        ALOGE("CamDev: Failed to open %s: %s", device_path, strerror(errno));
        return -errno;
    }
    
    // Send DCAM_INIT ioctl
    int ret = ioctl(dev->dcam_fd, DCAM_INIT, 0);
    if (ret < 0) {
        ALOGE("CamDev: DCAM_INIT ioctl failed: %s", strerror(errno));
        close(dev->dcam_fd);
        return -errno;
    }
    
    ALOGD("CamDev: %s opened fd=%d", device_path, dev->dcam_fd);
    return dev->dcam_fd;
}

/*
 * Start streaming (Camera3 HAL3 integration)
 */
int camdev_start_stream(camdev_t *dev) {
    HAL_CONFIG_LOCK(&dev->device_mutex);
    
    if (dev->streaming) {
        ALOGW("CamDev: %s already streaming", dev->name);
        HAL_CONFIG_UNLOCK(&dev->device_mutex);
        return 0;
    }
    
    // Start libcamera.c streaming pipeline
    stream_start(dev->stream_handle);
    
    // Start dcam.c kernel streaming
    ioctl(dev->dcam_fd, DCAM_STREAM_START, 0);
    
    dev->streaming = 1;
    ALOGI("CamDev: %s streaming started @%u FPS", dev->name, dev->config.fps);
    
    HAL_CONFIG_UNLOCK(&dev->device_mutex);
    return 0;
}

/*
 * Stop streaming
 */
int camdev_stop_stream(camdev_t *dev) {
    HAL_CONFIG_LOCK(&dev->device_mutex);
    
    if (!dev->streaming) {
        HAL_CONFIG_UNLOCK(&dev->device_mutex);
        return 0;
    }
    
    stream_stop(dev->stream_handle);
    ioctl(dev->dcam_fd, DCAM_STREAM_STOP, 0);
    
    dev->streaming = 0;
    ALOGI("CamDev: %s streaming stopped", dev->name);
    
    HAL_CONFIG_UNLOCK(&dev->device_mutex);
    return 0;
}

/*
 * Camera3 HAL3 device operations → camdev mapping
 */
static int camdev_configure_streams(struct camera3_device *dev,
                                   camera3_stream_configuration_t *stream_list) {
    camdev_t *camdev = (camdev_t*)dev->priv;
    
    HAL_CONFIG_LOCK(&camdev->device_mutex);
    
    // Parse stream list and configure libcamera.c
    for (uint32_t i = 0; i < stream_list->num_streams; i++) {
        camera3_stream_t *stream = stream_list->streams[i];
        
        camdev->config.width = stream->width;
        camdev->config.height = stream->height;
        camera_set_config(camdev->cam_handle, &camdev->config);
    }
    
    HAL_CONFIG_UNLOCK(&camdev->device_mutex);
    return 0;
}

static int camdev_process_capture_request(struct camera3_device *dev,
                                         camera3_capture_request_t *request) {
    camdev_t *camdev = (camdev_t*)dev->priv;
    
    HAL_STREAM_LOCK(&camdev->device_mutex);
    
    // Queue buffers to libcamera.c pipeline
    for (uint32_t i = 0; i < request->num_output_buffers; i++) {
        stream_queue_buffer(camdev->stream_handle, 
                           request->output_buffers[i].buffer);
    }
    
    camdev->frame_counter++;
    
    HAL_STREAM_UNLOCK(&camdev->device_mutex);
    return 0;
}

/*
 * PiP integration (cam3_pip.c)
 */
int camdev_enable_pip(camdev_t *dev, int enable) {
    if (enable) {
        HAL_CONFIG_LOCK(&dev->device_mutex);
        cam3_pip_init((camera3_device_t*)&dev->hal3_device);
        dev->pip_enabled = 1;
        HAL_CONFIG_UNLOCK(&dev->device_mutex);
        ALOGI("CamDev: %s PiP enabled", dev->name);
    }
    return 0;
}

/*
 * Get device statistics
 */
void camdev_get_stats(camdev_t *dev, uint64_t *frames, float *fps) {
    HAL_CONFIG_LOCK(&dev->device_mutex);
    *frames = dev->frame_counter;
    *fps = dev->current_fps;
    HAL_CONFIG_UNLOCK(&dev->device_mutex);
}

/*
 * Cleanup single device
 */
void camdev_cleanup(camdev_t *dev) {
    camdev_stop_stream(dev);
    preview_stop(dev->preview_handle);
    stream_destroy(dev->stream_handle);
    camera_release(dev->cam_handle);
    close(dev->dcam_fd);
    hal_mutex_destroy(&dev->device_mutex);
    
    ALOGI("CamDev: %s cleaned up", dev->name);
}

/*
 * Camera3 HAL3 device ops table
 */
static camera3_device_ops_t camdev_ops = {
    .configure_streams      = camdev_configure_streams,
    .process_capture_request = camdev_process_capture_request,
    .flush                  = NULL,
};

/*
 * HAL3 device constructor
 */
int camdev_create_hal3_device(int id, camera3_device_t **out_dev) {
    camdev_t *dev = &g_devices[id];
    
    camera3_device_t *hal3_dev = calloc(1, sizeof(camera3_device_t));
    if (!hal3_dev) return -ENOMEM;
    
    hal3_dev->common.tag = HARDWARE_DEVICE_TAG;
    hal3_dev->common.version = CAMERA_DEVICE_API_VERSION_3_4;
    hal3_dev->common.close = (int (*)(struct hw_device_t*))camdev_close;
    hal3_dev->ops = &camdev_ops;
    hal3_dev->priv = dev;
    
    *out_dev = hal3_dev;
    return 0;
}

static int camdev_close(struct hw_device_t *hw_dev) {
    camera3_device_t *dev = (camera3_device_t*)hw_dev;
    camdev_t *camdev = (camdev_t*)dev->priv;
    camdev_cleanup(camdev);
    free(dev);
    return 0;
}

/*
 * Public API - Get camera device by ID
 */
camdev_t *camdev_get_device(int id) {
    if (id >= CAMDEV_MAX_CAMERAS || !g_devices_initialized) {
        return NULL;
    }
    return &g_devices[id];
}